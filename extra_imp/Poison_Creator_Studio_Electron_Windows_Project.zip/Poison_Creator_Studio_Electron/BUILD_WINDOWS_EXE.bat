@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Get the LTS version at https://nodejs.org/
  pause
  exit /b 1
)
if not exist "node_modules\" (
  echo Installing dependencies. This needs internet the first time...
  call npm.cmd install
  if errorlevel 1 goto :failed
)
echo Building Poison Creator Studio Windows installer and portable EXE...
call npm.cmd run dist:win
if errorlevel 1 goto :failed
echo.
echo Done. Your Windows files are in the release folder.
pause
exit /b 0
:failed
echo.
echo Windows build failed. See the error above.
pause
exit /b 1
