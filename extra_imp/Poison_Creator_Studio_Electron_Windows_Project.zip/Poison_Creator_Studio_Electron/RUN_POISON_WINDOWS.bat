@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Get the LTS version at https://nodejs.org/
  pause
  exit /b 1
)
if not exist "node_modules\" (
  echo Installing dependencies. This needs internet the first time...
  call npm.cmd install
  if errorlevel 1 goto :failed
)
echo Starting Poison Creator Studio...
call npm.cmd run dev
if errorlevel 1 goto :failed
exit /b 0
:failed
echo.
echo Poison could not start. See the error above.
pause
exit /b 1
